"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { LandingStartSection } from "@/features/landing/components/LandingStartSection";

const contentSections = [
  {
    eyebrow: "WHY",
    title: "사이즈 실패가 생기는 이유",
    body:
      "브랜드마다 같은 M, L이라도 기준 실측이 다릅니다. 가슴, 허리, 총장, 소매 같은 부위별 치수가 조금만 달라도 실제 착용감은 크게 달라질 수 있습니다.",
    points: ["브랜드별 사이즈 기준 차이", "부위별 실측 차이", "후기만으로 판단하기 어려운 내 체형 변수"],
  },
  {
    eyebrow: "INPUT",
    title: "추천에 사용하는 정보",
    body:
      "Project S는 키와 몸무게만 보지 않습니다. 사용자가 실제로 잘 맞는 옷의 실측과 부위별 착용감을 함께 저장해 추천 기준으로 사용합니다.",
    points: ["키, 몸무게, 선택 성별", "잘 맞는 상의/하의의 cm 실측", "작음 또는 큼 같은 부위별 착용감"],
  },
  {
    eyebrow: "RESULT",
    title: "결과에서 확인하는 것",
    body:
      "상품 사이즈표와 내 기준 옷을 비교해서 권장 사이즈를 보여주고, 어느 부위가 여유롭거나 타이트할 수 있는지 함께 정리합니다.",
    points: ["권장 사이즈", "추천 이유", "부위별 예상 핏", "최근 분석 기록"],
  },
];

const coreSteps = [
  "프로필 입력",
  "기준 옷 실측 입력",
  "상품 선택",
  "사이즈 분석",
  "결과 확인",
];

export function LandingTimelineDetails() {
  return (
    <section style={{ display: "grid", gap: "1.4rem" }}>
      {contentSections.map((item, idx) => (
        <motion.article
          key={item.eyebrow}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.28 }}
          transition={{ duration: 0.42, delay: idx * 0.06 }}
          style={{
            position: "relative",
            minHeight: 250,
            borderBottom: "1px solid rgba(255,255,255,0.1)",
          }}
        >
          <div
            style={{
              padding: "1.75rem 0.3rem 1.65rem",
              display: "grid",
              gap: "1.25rem",
              minHeight: 250,
            }}
          >
            <div>
              <p style={{ margin: 0, fontSize: "0.78rem", color: "#9fb1cc", letterSpacing: 0.5 }}>{item.eyebrow}</p>
              <h3
                style={{
                  margin: "0.4rem 0 0.65rem",
                  fontSize: "clamp(1.55rem, 3.8vw, 2.55rem)",
                  lineHeight: 1.08,
                  color: "#f3f3f3",
                  maxWidth: "14ch",
                }}
              >
                {item.title}
              </h3>
              <p style={{ margin: 0, color: "#cfcfcf", lineHeight: 1.75, maxWidth: "62ch", fontSize: "0.98rem" }}>
                {item.body}
              </p>
            </div>

            <ul
              style={{
                margin: 0,
                padding: 0,
                listStyle: "none",
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(190px, 1fr))",
                gap: "0.75rem",
              }}
            >
              {item.points.map((point) => (
                <li
                  key={point}
                  style={{
                    minHeight: 58,
                    padding: "0.78rem 0.85rem",
                    borderRadius: 8,
                    border: "1px solid rgba(255,255,255,0.1)",
                    background: "rgba(255,255,255,0.045)",
                    color: "#e7e7e7",
                    lineHeight: 1.45,
                    fontSize: "0.92rem",
                  }}
                >
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </motion.article>
      ))}

      <motion.section
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.28 }}
        transition={{ duration: 0.42 }}
        style={{
          padding: "1.7rem 0.3rem 1.4rem",
          display: "grid",
          gap: "1rem",
          borderBottom: "1px solid rgba(255,255,255,0.1)",
        }}
      >
        <div>
          <p style={{ margin: 0, fontSize: "0.78rem", color: "#9fb1cc", letterSpacing: 0.5 }}>STEPS</p>
          <h3
            style={{
              margin: "0.4rem 0 0.65rem",
              fontSize: "clamp(1.55rem, 3.8vw, 2.55rem)",
              lineHeight: 1.08,
              color: "#f3f3f3",
            }}
          >
            핵심 진행 단계
          </h3>
          <p style={{ margin: 0, color: "#cfcfcf", lineHeight: 1.75, maxWidth: "62ch", fontSize: "0.98rem" }}>
            아래 순서대로 정보를 입력하면 상품별 권장 사이즈와 부위별 예상 착용감을 확인할 수 있습니다.
          </p>
        </div>

        <ol
          style={{
            margin: 0,
            padding: 0,
            listStyle: "none",
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
            gap: "0.75rem",
            counterReset: "core-step",
          }}
        >
          {coreSteps.map((step, idx) => (
            <li
              key={step}
              style={{
                minHeight: 76,
                padding: "0.85rem",
                borderRadius: 8,
                border: "1px solid rgba(255,255,255,0.11)",
                background: "rgba(6, 8, 12, 0.34)",
                color: "#eceff4",
              }}
            >
              <p style={{ margin: "0 0 0.35rem", color: "#9fb1cc", fontSize: "0.78rem", fontWeight: 700 }}>
                STEP {idx + 1}
              </p>
              <p style={{ margin: 0, fontWeight: 700 }}>{step}</p>
            </li>
          ))}
        </ol>

        <div
          style={{
            maxWidth: 420,
            width: "100%",
            marginTop: "0.45rem",
          }}
        >
          <LandingStartSection />
        </div>
      </motion.section>

      <section
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: "0.8rem",
          flexWrap: "wrap",
          color: "#cbcbcb",
          fontSize: "0.9rem",
        }}
      >
        <span>추천은 입력한 실측과 mock 상품 사이즈표를 기준으로 한 참고 결과입니다.</span>
        <span>
          <Link href="/privacy">개인정보</Link> · <Link href="/terms">이용약관</Link>
        </span>
      </section>
    </section>
  );
}

"use client";

import { useRouter } from "next/navigation";
import { Button } from "@/components/common/Button";
import { useFlowBootstrapStore } from "@/stores/flowBootstrapStore";

export function LandingStartSection() {
  const router = useRouter();
  const acknowledgeIntro = useFlowBootstrapStore((s) => s.acknowledgeIntro);

  function startProfileStep() {
    acknowledgeIntro();
    router.push("/profile");
  }

  return (
    <p style={{ marginTop: 0, marginBottom: 0, width: "100%", textAlign: "left" }}>
      <Button
        type="button"
        onClick={startProfileStep}
        style={{
          width: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontWeight: 700,
          borderRadius: 14,
          padding: "0.78rem 1.1rem",
          fontSize: "0.95rem",
          border: "1px solid rgba(190, 204, 232, 0.38)",
          background:
            "linear-gradient(155deg, rgba(78, 111, 149, 0.95) 0%, rgba(89, 80, 135, 0.92) 48%, rgba(69, 130, 118, 0.92) 100%)",
          color: "#f5f8ff",
          boxShadow: "0 10px 28px rgba(20, 28, 48, 0.45), inset 0 1px 0 rgba(255,255,255,0.12)",
        }}
      >
        내 사이즈 추천 시작하기
      </Button>
    </p>
  );
}

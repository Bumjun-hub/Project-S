// 이 파일은 서비스 진입 랜딩 화면을 정의합니다.
import { AceternityHero } from "@/features/landing/components/AceternityHero";
import { LandingTimelineDetails } from "@/features/landing/components/LandingTimelineDetails";

const landingIntroBandStyle = {
  width: "100%",
  background: "rgba(0, 0, 0, 0.58)",
  WebkitBackdropFilter: "blur(9px)",
  backdropFilter: "blur(9px)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.04)",
  borderBottom: "1px solid rgba(255,255,255,0.09)",
};

/** Sticky 헤더( pill + 상단 여백) 만큼 밴드를 위로 끌어올려, 맨 위·헤더 뒤 영역까지 동일 배경이 보이게 함 */
const landingIntroBandBleedAboveHeader = {
  marginTop: "calc(-1 * (clamp(4.1rem, 10vw, 5.4rem)))",
  paddingTop: "calc(env(safe-area-inset-top, 0px) + clamp(4.1rem, 10vw, 5.4rem) + 0.75rem)",
};

/** 타임라인: 인트로보다 살연한 반투명 + 블러로 긴 본문 읽기 구역만 구분 */
const landingTimelineZoneStyle = {
  width: "100%",
  borderTop: "1px solid rgba(255,255,255,0.07)",
  background: "linear-gradient(180deg, rgba(0,0,0,0.42) 0%, rgba(0,0,0,0.22) 45%, transparent 100%)",
  WebkitBackdropFilter: "blur(7px)",
  backdropFilter: "blur(7px)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.03)",
};

export default function LandingScreen() {
  return (
    <main style={{ position: "relative" }}>
      <div style={{ ...landingIntroBandStyle, ...landingIntroBandBleedAboveHeader }}>
        <AceternityHero />
      </div>

      <div style={landingTimelineZoneStyle}>
        <div
          style={{
            padding: "clamp(1.85rem, 4.5vw, 2.6rem) clamp(1.25rem, 4vw, 2rem)",
            paddingBottom: "2.65rem",
            maxWidth: 980,
            margin: "0 auto",
          }}
        >
          <LandingTimelineDetails />
        </div>
      </div>
    </main>
  );
}

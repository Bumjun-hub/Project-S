"use client";

import type { CSSProperties } from "react";
import { motion } from "framer-motion";
import { FlowStepCaption } from "@/components/common/FlowStepCaption";

const headlineStress: CSSProperties = {
  fontWeight: 800,
  fontSize: "1.08em",
  color: "#ffffff",
};

const heroPoints = [
  "브랜드마다 다른 사이즈 기준",
  "내 기준 옷과 상품 실측 비교",
  "권장 사이즈와 부위별 핏 예측",
];

export function AceternityHero() {
  return (
    <section
      style={{
        width: "100%",
        padding: "clamp(1rem, 2.5vw, 1.65rem) clamp(1.35rem, 4.5vw, 3rem) 2.65rem",
        color: "#f5f5f5",
      }}
    >
      <div
        style={{
          maxWidth: "min(1180px, 100%)",
          margin: "0 auto",
        }}
      >
        <FlowStepCaption step={1} label="프로젝트 소개" align="center" />

        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "clamp(1.75rem, 4.2vw, 3.25rem)",
            alignItems: "flex-start",
          }}
        >
          <div
            style={{
              flex: "1 1 min(360px, 100%)",
              minWidth: 0,
              display: "grid",
              gap: "0.75rem",
            }}
          >
            <motion.p
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              style={{
                margin: 0,
                color: "#c8c8c8",
                letterSpacing: "0.02em",
                fontSize: "0.86rem",
                fontWeight: 500,
              }}
            >
              AI Fit Recommender · Project S
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.06 }}
              style={{
                margin: 0,
                lineHeight: 1.2,
                fontSize: "clamp(1.75rem, 3.3vw, 2.7rem)",
                fontWeight: 600,
                maxWidth: "21ch",
              }}
            >
              <strong style={headlineStress}>내 옷 실측</strong>을 기준으로
              <br />
              사이즈 실패를 줄이는
              <br />
              <strong style={headlineStress}>추천 플로우</strong>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.12 }}
              style={{
                margin: "0.35rem 0 0",
                color: "#dcdcdc",
                lineHeight: 1.75,
                fontSize: "0.98rem",
                maxWidth: "58ch",
              }}
            >
              키와 몸무게만으로 판단하지 않고, 실제로 잘 맞는 옷의 실측과 상품 사이즈표를 함께 비교합니다.
              아래 내용을 읽고 나면 어떤 정보를 입력해야 하고 어떤 결과를 받는지 바로 이해할 수 있습니다.
            </motion.p>
          </div>

          <motion.aside
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18 }}
            style={{
              flex: "1 1 min(260px, 100%)",
              maxWidth: "min(100%, 420px)",
              minWidth: 0,
              alignSelf: "stretch",
              display: "flex",
            }}
          >
            <div
              style={{
                width: "100%",
                display: "flex",
                flexDirection: "column",
                gap: "0.85rem",
                padding: "1.15rem 1.18rem",
                borderRadius: 18,
                border: "1px solid rgba(255,255,255,0.11)",
                background:
                  "linear-gradient(165deg, rgba(255,255,255,0.065) 0%, rgba(255,255,255,0.02) 55%, rgba(12,14,18,0.25) 100%)",
                boxShadow: "0 14px 40px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.06)",
              }}
            >
              <p
                style={{
                  margin: 0,
                  fontSize: "0.74rem",
                  fontWeight: 600,
                  letterSpacing: "0.12em",
                  textTransform: "uppercase",
                  color: "rgba(200, 210, 230, 0.58)",
                }}
              >
                핵심 기준
              </p>

              <ul
                style={{
                  margin: 0,
                  padding: 0,
                  listStyle: "none",
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                }}
              >
                {heroPoints.map((point, i) => (
                  <motion.li
                    key={point}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.36, delay: 0.2 + i * 0.07 }}
                    style={{
                      padding: "0.68rem 0.75rem",
                      borderRadius: 13,
                      background: "rgba(6, 8, 12, 0.35)",
                      border: "1px solid rgba(255,255,255,0.07)",
                      color: "#eceff4",
                      fontSize: "0.92rem",
                      fontWeight: 600,
                    }}
                  >
                    {point}
                  </motion.li>
                ))}
              </ul>

              <p style={{ margin: 0, color: "#cfcfcf", lineHeight: 1.65, fontSize: "0.9rem" }}>
                시작 버튼은 설명을 모두 확인한 뒤 누를 수 있도록 페이지 맨 아래에 배치했습니다.
              </p>
            </div>
          </motion.aside>
        </div>
      </div>
    </section>
  );
}

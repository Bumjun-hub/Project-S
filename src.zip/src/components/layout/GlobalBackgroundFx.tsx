"use client";

import { GridMotion } from "@/components/background/GridMotion";

const BG_ITEMS = [
  { title: "Look 1", image: "/images/cloth1.jpg" },
  { title: "Look 2", image: "/images/cloth1.jpg" },
  { title: "Look 3", image: "/images/cloth1.jpg" },
  { title: "Look 4", image: "/images/cloth1.jpg" },
];

export function GlobalBackgroundFx() {
  return (
    <div
      aria-hidden
      style={{
        position: "fixed",
        inset: 0,
        pointerEvents: "none",
        overflow: "hidden",
        zIndex: 0,
        background:
          "radial-gradient(circle at 50% 10%, rgba(47,47,50,0.3), rgba(8,8,8,0.1) 45%, rgba(6,6,6,0) 70%)",
      }}
    >
      <GridMotion gradientColor="#2f2f32" items={BG_ITEMS} />
      <div
        style={{
          position: "absolute",
          width: 520,
          height: 520,
          top: -220,
          left: -180,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(104, 114, 132, 0.22), rgba(104, 114, 132, 0))",
          filter: "blur(30px)",
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 640,
          height: 640,
          right: -260,
          bottom: -260,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(88, 96, 112, 0.25), rgba(88, 96, 112, 0))",
          filter: "blur(34px)",
        }}
      />
    </div>
  );
}

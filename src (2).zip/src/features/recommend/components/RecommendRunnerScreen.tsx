// 이 파일은 상품 추천 분석 실행 화면과 결과 저장 흐름을 담당합니다.
"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { FlowStepCaption } from "@/components/common/FlowStepCaption";
import { PageContainer } from "@/components/layout/PageContainer";
import { useAnalysisHistoryStore } from "@/features/history/store";
import { useFitReferenceStore } from "@/features/my-fit/store";
import { useUserProfileStore } from "@/features/profile/store";
import { stableRecommendationRecordId } from "@/features/recommend/utils/stable-record-id";
import { getMockProduct } from "@/mocks/products.mock";
import { buildMockRecommendation, delayMs } from "@/mocks/recommendation.mock";

export default function RecommendRunnerScreen({ productId }: { productId: string }) {
  const router = useRouter();
  const profile = useUserProfileStore((s) => s.profile);
  const myFit = useFitReferenceStore((s) => s.myFit);
  const commitRecommendation = useAnalysisHistoryStore((s) => s.commitRecommendation);

  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function run() {
      const product = getMockProduct(productId);
      if (!product) {
        setError("상품을 찾을 수 없습니다.");
        return;
      }
      if (profile.heightCm == null || profile.weightKg == null) {
        setError("프로필(키·몸무게)을 먼저 입력해 주세요.");
        return;
      }
      const hasAnyMyFit = (Object.keys(myFit.entries) as Array<keyof typeof myFit.entries>).some((k) => {
        const entry = myFit.entries[k];
        return (
          entry.garmentLabel.trim() !== "" &&
          entry.measurements.some((m) => m.sizeCm != null && m.feeling != null)
        );
      });
      if (!hasAnyMyFit) {
        setError("기준 옷 실측(카테고리/사이즈/착용감)을 먼저 입력해 주세요.");
        return;
      }
      await delayMs(900);
      if (cancelled) return;
      const base = buildMockRecommendation({ product, profile, myFit });
      const record = {
        ...base,
        id: stableRecommendationRecordId(productId, profile, myFit),
        createdAt: new Date().toISOString(),
      };
      commitRecommendation(record);
      router.replace("/result");
    }

    void run();

    return () => {
      cancelled = true;
    };
  }, [productId, profile, myFit, commitRecommendation, router]);

  if (error) {
    return (
      <PageContainer maxWidth={560}>
        <FlowStepCaption step={6} label="사이즈 분석" />
        <h1 style={{ marginTop: 0 }}>분석 불가</h1>
        <p style={{ color: "var(--muted)" }}>{error}</p>
        <p>
          <Link href="/profile">프로필</Link>
          {" · "}
          <Link href="/my-fit">기준 옷</Link>
          {" · "}
          <Link href="/products">상품</Link>
        </p>
      </PageContainer>
    );
  }

  return (
    <PageContainer maxWidth={560}>
      <FlowStepCaption step={6} label="사이즈 분석" />
      <h1 style={{ marginTop: 0 }}>mock AI 분석 중…</h1>
      <p style={{ color: "var(--muted)" }}>프로필·기준 옷·상품 사이즈표를 합쳐 권장 라벨을 만듭니다.</p>
    </PageContainer>
  );
}

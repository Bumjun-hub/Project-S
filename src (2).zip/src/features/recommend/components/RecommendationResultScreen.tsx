// 이 파일은 마지막 추천 결과 화면의 UI와 기록 연동을 담당합니다.
"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { FlowStepCaption } from "@/components/common/FlowStepCaption";
import { PageContainer } from "@/components/layout/PageContainer";
import { useAnalysisHistoryStore } from "@/features/history/store";

export default function RecommendationResultScreen() {
  const lastResult = useAnalysisHistoryStore((s) => s.lastResult);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    setReady(true);
  }, []);

  if (!ready) {
    return (
      <PageContainer maxWidth={640}>
        <p style={{ color: "var(--muted)" }}>불러오는 중…</p>
      </PageContainer>
    );
  }

  if (!lastResult) {
    return (
      <PageContainer maxWidth={640}>
        <FlowStepCaption step={7} label="추천 결과" />
        <h1 style={{ marginTop: 0 }}>아직 결과가 없습니다</h1>
        <p style={{ color: "var(--muted)" }}>상품 상세에서 사이즈 분석을 실행하면 여기에 표시됩니다.</p>
        <p>
          <Link href="/products">상품 목록</Link>
        </p>
      </PageContainer>
    );
  }

  return (
    <PageContainer maxWidth={640}>
      <FlowStepCaption step={7} label="추천 결과" />
      <h1 style={{ marginTop: 0 }}>추천 결과</h1>
      <p style={{ fontSize: "0.85rem", color: "var(--muted)" }}>
        {new Date(lastResult.createdAt).toLocaleString("ko-KR")} · {lastResult.brand}
      </p>
      <h2 style={{ fontSize: "1.15rem", marginBottom: "0.25rem" }}>{lastResult.productName}</h2>
      <p style={{ fontSize: "1.5rem", fontWeight: 700, margin: "0.5rem 0" }}>
        권장 사이즈: {lastResult.recommendedSize}
      </p>
      <p style={{ lineHeight: 1.65, whiteSpace: "pre-wrap" }}>{lastResult.summary}</p>
      {lastResult.fitInsights.length > 0 ? (
        <section style={{ marginTop: "1rem" }}>
          <h3 style={{ marginBottom: "0.5rem" }}>부위별 사이즈 비교</h3>
          <ul style={{ margin: 0, paddingLeft: "1.15rem", display: "grid", gap: "0.25rem" }}>
            {lastResult.fitInsights.map((insight) => (
              <li key={insight}>{insight}</li>
            ))}
          </ul>
        </section>
      ) : null}
      <p style={{ marginTop: "1.5rem" }}>
        <Link href={`/recommend/${lastResult.productId}`} style={{ fontWeight: 600 }}>
          같은 상품 다시 분석
        </Link>
        {" · "}
        <Link href="/products">다른 상품</Link>
        {" · "}
        <Link href="/history">최근 기록</Link>
      </p>
      <p>
        <Link href="/">홈</Link>
      </p>
    </PageContainer>
  );
}

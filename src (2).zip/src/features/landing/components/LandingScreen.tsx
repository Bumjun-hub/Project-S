// 이 파일은 서비스 진입 랜딩 화면을 정의합니다.
import { AceternityHero } from "@/features/landing/components/AceternityHero";
import { LandingTimelineDetails } from "@/features/landing/components/LandingTimelineDetails";

/** backdrop-filter 미사용: 움직이는 Grid 아래에서는 블러 재합성 비용이 매우 큼 */
const landingIntroBandStyle = {
  width: "100%",
  background:
    // same tone as 아래 섹션과 이어지도록, 아래로 갈수록 투명해지며 자연스럽게 페이드 아웃
    "linear-gradient(180deg, rgba(16, 16, 24, 0.82) 0%, rgba(12, 12, 18, 0.72) 55%, rgba(10, 10, 16, 0.44) 85%, rgba(9, 9, 14, 0.18) 100%)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.05)",
};

/** Sticky 헤더( pill + 상단 여백) 만큼 밴드를 위로 끌어올려, 맨 위·헤더 뒤 영역까지 동일 배경이 보이게 함 */
const landingIntroBandBleedAboveHeader = {
  marginTop: "calc(-1 * (clamp(4.1rem, 10vw, 5.4rem)))",
  paddingTop: "calc(env(safe-area-inset-top, 0px) + clamp(4.1rem, 10vw, 5.4rem) + 0.75rem)",
};

/** 타임라인: 위 섹션과 같은 톤으로 이어지도록, 위에서 살짝만 올라오고 아래로 페이드 */
const landingTimelineZoneStyle = {
  width: "100%",
  background:
    "linear-gradient(180deg, rgba(16, 16, 24, 0.62) 0%, rgba(12, 12, 18, 0.48) 45%, rgba(10, 10, 16, 0.28) 70%, rgba(10, 10, 16, 0.08) 100%)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.04)",
};

export default function LandingScreen() {
  return (
    <main style={{ position: "relative" }}>
      <div style={{ ...landingIntroBandStyle, ...landingIntroBandBleedAboveHeader }}>
        <AceternityHero />
      </div>

      <div style={landingTimelineZoneStyle}>
        <div
          style={{
            padding: "clamp(1.85rem, 4.5vw, 2.6rem) clamp(1.25rem, 4vw, 2rem)",
            paddingBottom: "2.65rem",
            maxWidth: "min(1180px, 100%)",
            margin: "0 auto",
          }}
        >
          <LandingTimelineDetails />
        </div>
      </div>
    </main>
  );
}

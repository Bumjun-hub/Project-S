"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { LandingStartSection } from "@/features/landing/components/LandingStartSection";

export function LandingTimelineDetails() {
  const flowSteps = ["프로필 입력", "기준 옷 등록", "상품 선택", "AI 분석", "결과 확인"];

  const sectionMotion = {
    initial: { opacity: 0, y: 24 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true, amount: 0.24 },
    transition: { duration: 0.45 },
  } as const;

  const sectionShellStyle = {
    paddingBlock: "clamp(1.9rem, 5vw, 3.2rem)",
    display: "grid",
    gap: "1.2rem",
  } as const;

  const showcaseGridStyle = {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 320px), 1fr))",
    gap: "clamp(0.9rem, 2vw, 1.4rem)",
    alignItems: "center",
  } as const;

  return (
    <section style={{ display: "grid", gap: "clamp(1.25rem, 3.2vw, 2.4rem)" }}>
      <motion.section
        {...sectionMotion}
        style={{
          ...sectionShellStyle,
          position: "relative",
          isolation: "isolate",
        }}
      >
        <div
          aria-hidden
          style={{
            position: "absolute",
            inset: "-10% 0 auto auto",
            width: 260,
            height: 220,
            borderRadius: "50%",
            background: "radial-gradient(circle, rgba(96, 121, 236, 0.18) 0%, rgba(96, 121, 236, 0) 72%)",
            filter: "blur(10px)",
            pointerEvents: "none",
            zIndex: -1,
          }}
        />
        <div style={showcaseGridStyle}>
          <div style={{ display: "grid", gap: "0.86rem", maxWidth: 520 }}>
            <p style={{ margin: 0, fontSize: "0.75rem", letterSpacing: "0.11em", fontWeight: 800, color: "#9db7ec" }}>PROBLEM</p>
            <h3 style={{ margin: 0, color: "#eef3ff", fontSize: "clamp(1.45rem, 3.4vw, 2.25rem)", lineHeight: 1.16, letterSpacing: "-0.02em" }}>
              브랜드마다 같은 M이어도
              <br />
              실제 실측은 다릅니다
            </h3>
            <p style={{ margin: 0, color: "#bec8e3", lineHeight: 1.66, fontSize: "0.97rem", maxWidth: 420 }}>
              작은 수치 차이가 착용감 실패로 이어집니다. 사이즈 표기보다 실측 비교가 더 정확합니다.
            </p>
          </div>

          <div
            style={{
              position: "relative",
              minHeight: 210,
              display: "grid",
              placeItems: "center",
            }}
          >
            <div
              aria-hidden
              style={{
                position: "absolute",
                width: 180,
                height: 180,
                borderRadius: "50%",
                background: "radial-gradient(circle, rgba(101,119,238,0.24) 0%, rgba(101,119,238,0) 70%)",
                filter: "blur(6px)",
              }}
            />
            <motion.div
              whileHover={{ y: -3, rotate: -1.2 }}
              transition={{ duration: 0.22 }}
              style={{
                position: "absolute",
                top: "14%",
                left: "8%",
                width: "min(100%, 235px)",
                borderRadius: 14,
                background: "linear-gradient(160deg, rgba(21,28,49,0.82), rgba(11,16,32,0.76))",
                boxShadow: "0 16px 34px rgba(8, 16, 36, 0.45)",
                padding: "0.82rem 0.86rem",
                display: "grid",
                gap: "0.7rem",
                backdropFilter: "blur(6px)",
              }}
            >
              <p style={{ margin: 0, color: "#eff3ff", fontWeight: 700, fontSize: "0.92rem" }}>Nike M</p>
              <div style={{ display: "flex", justifyContent: "space-between", color: "#bcc9e7", fontSize: "0.84rem" }}>
                <span>총장 69</span>
                <span>어깨 52</span>
              </div>
            </motion.div>
            <motion.div
              whileHover={{ y: -3, rotate: 1.4 }}
              transition={{ duration: 0.22 }}
              style={{
                position: "absolute",
                bottom: "8%",
                right: "5%",
                width: "min(100%, 245px)",
                borderRadius: 14,
                background: "linear-gradient(160deg, rgba(27,23,54,0.84), rgba(14,16,36,0.74))",
                boxShadow: "0 16px 34px rgba(8, 16, 36, 0.45)",
                padding: "0.82rem 0.86rem",
                display: "grid",
                gap: "0.7rem",
                backdropFilter: "blur(6px)",
              }}
            >
              <p style={{ margin: 0, color: "#eff3ff", fontWeight: 700, fontSize: "0.92rem" }}>Musinsa M</p>
              <div style={{ display: "flex", justifyContent: "space-between", color: "#bcc9e7", fontSize: "0.84rem" }}>
                <span>총장 72</span>
                <span>어깨 56</span>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.section>

      <motion.section {...sectionMotion} style={sectionShellStyle}>
        <div style={{ display: "grid", gap: "0.62rem" }}>
          <p style={{ margin: 0, fontSize: "0.75rem", letterSpacing: "0.11em", fontWeight: 800, color: "#9db7ec" }}>INPUT EXPERIENCE</p>
          <h3 style={{ margin: 0, color: "#eef3ff", fontSize: "clamp(1.2rem, 2.9vw, 1.72rem)", lineHeight: 1.27 }}>
            입력 화면 그대로, 분석 기준을 빠르게 준비
          </h3>
        </div>
        <div style={{ display: "grid", gap: "0.2rem" }}>
          {[
            { label: "키", value: "172cm" },
            { label: "몸무게", value: "63kg" },
            { label: "기준 옷", value: "Nike Hoodie M" },
            { label: "어깨", value: "52cm" },
          ].map((field) => (
            <motion.div
              key={field.label}
              whileHover={{ x: 2 }}
              transition={{ duration: 0.2 }}
              style={{
                display: "grid",
                gap: "0.32rem",
                padding: "0.8rem 0.12rem 0.72rem",
                borderBottom: "1px solid rgba(154, 172, 218, 0.34)",
              }}
            >
              <p style={{ margin: 0, fontSize: "0.74rem", color: "#9fb1d8", fontWeight: 700, letterSpacing: "0.05em" }}>{field.label}</p>
              <p style={{ margin: 0, fontSize: "1.03rem", color: "#edf2ff", fontWeight: 700 }}>{field.value}</p>
            </motion.div>
          ))}
        </div>
      </motion.section>

      <motion.section
        {...sectionMotion}
        style={{
          ...sectionShellStyle,
          position: "relative",
          isolation: "isolate",
        }}
      >
        <div
          aria-hidden
          style={{
            position: "absolute",
            top: "-8%",
            right: "-2%",
            width: 300,
            height: 210,
            borderRadius: "50%",
            background: "radial-gradient(circle, rgba(102, 123, 244, 0.2) 0%, rgba(102, 123, 244, 0) 72%)",
            filter: "blur(10px)",
            pointerEvents: "none",
            zIndex: -1,
          }}
        />
        <div
          aria-hidden
          style={{
            position: "absolute",
            bottom: "-14%",
            left: "-4%",
            width: 260,
            height: 180,
            borderRadius: "50%",
            background: "radial-gradient(circle, rgba(145, 94, 232, 0.16) 0%, rgba(145, 94, 232, 0) 70%)",
            filter: "blur(12px)",
            pointerEvents: "none",
            zIndex: -1,
          }}
        />
        <p style={{ margin: 0, fontSize: "0.75rem", letterSpacing: "0.11em", fontWeight: 800, color: "#a8bfff" }}>AI RESULT SHOWCASE</p>
        <div style={showcaseGridStyle}>
          <div style={{ display: "grid", gap: "0.7rem" }}>
            <h3 style={{ margin: 0, color: "#f0f4ff", fontSize: "clamp(1.35rem, 3.2vw, 2rem)", lineHeight: 1.18 }}>
              추천 사이즈 <span style={{ color: "#d8e0ff" }}>M</span>
            </h3>
            <p style={{ margin: 0, color: "#c8d3f0", fontSize: "0.96rem", lineHeight: 1.6 }}>예상 핏: 세미 오버핏</p>
          </div>

          <div
            style={{
              borderRadius: 20,
              background: "linear-gradient(162deg, rgba(12,17,33,0.74), rgba(8,12,24,0.7))",
              boxShadow: "0 18px 42px rgba(40, 58, 134, 0.26), inset 0 1px 0 rgba(255,255,255,0.08)",
              padding: "1rem",
              display: "grid",
              gap: "0.78rem",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <p style={{ margin: 0, color: "#edf2ff", fontWeight: 700, fontSize: "0.94rem" }}>실측 비교</p>
              <span
                style={{
                  fontSize: "0.71rem",
                  padding: "0.2rem 0.52rem",
                  borderRadius: 999,
                  color: "#dce6ff",
                  background: "rgba(85, 110, 208, 0.26)",
                }}
              >
                AI Fit Analysis
              </span>
            </div>
            {[
              { metric: "어깨", diff: "+2cm", width: "74%" },
              { metric: "총장", diff: "유사", width: "59%" },
              { metric: "품", diff: "약간 여유", width: "68%" },
            ].map((line) => (
              <div key={line.metric} style={{ display: "grid", gap: "0.36rem" }}>
                <div style={{ display: "flex", justifyContent: "space-between", color: "#c8d4f2", fontSize: "0.84rem" }}>
                  <span>{line.metric}</span>
                  <span>{line.diff}</span>
                </div>
                <div style={{ height: 5, borderRadius: 999, background: "rgba(142, 159, 207, 0.16)", overflow: "hidden" }}>
                  <div
                    style={{
                      width: line.width,
                      height: "100%",
                      borderRadius: 999,
                      background: "linear-gradient(90deg, rgba(112,146,244,0.98), rgba(146,111,232,0.98))",
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </motion.section>

      <motion.section
        {...sectionMotion}
        style={{
          ...sectionShellStyle,
          position: "relative",
          isolation: "isolate",
        }}
      >
        <div
          aria-hidden
          style={{
            position: "absolute",
            top: "10%",
            left: "-3%",
            width: 170,
            height: 140,
            borderRadius: "50%",
            background: "radial-gradient(circle, rgba(105, 128, 236, 0.12) 0%, rgba(105, 128, 236, 0) 72%)",
            filter: "blur(10px)",
            pointerEvents: "none",
            zIndex: -1,
          }}
        />
        <p style={{ margin: 0, fontSize: "0.75rem", letterSpacing: "0.11em", fontWeight: 800, color: "#9db7ec" }}>FLOW TIMELINE</p>
        <div
          style={{
            display: "grid",
            gap: "0.62rem",
            maxWidth: 420,
          }}
        >
          {flowSteps.map((step, idx) => (
            <div key={step} style={{ display: "grid", gap: "0.62rem" }}>
              <div style={{ display: "grid", gridTemplateColumns: "28px 1fr", gap: "0.7rem", alignItems: "center" }}>
                <div style={{ display: "grid", placeItems: "center" }}>
                  <span
                    style={{
                      width: 8,
                      height: 8,
                      borderRadius: "50%",
                      background: "linear-gradient(135deg, rgba(110, 148, 248, 1), rgba(146, 112, 236, 1))",
                      boxShadow: "0 0 14px rgba(117, 137, 236, 0.6)",
                    }}
                  />
                </div>
                <p style={{ margin: 0, color: "#dce6ff", fontSize: "0.93rem", letterSpacing: "-0.01em" }}>
                  <span style={{ color: "#9fb4e4", marginRight: "0.48rem", fontFamily: "monospace" }}>{String(idx + 1).padStart(2, "0")}</span>
                  {step}
                </p>
              </div>
              {idx < flowSteps.length - 1 ? (
                <div style={{ marginLeft: 13, width: 1, height: 22, background: "linear-gradient(180deg, rgba(126, 148, 218, 0.45), rgba(126, 148, 218, 0))" }} />
              ) : null}
            </div>
          ))}
        </div>
      </motion.section>

      <motion.section
        {...sectionMotion}
        style={{
          display: "grid",
          justifyItems: "center",
          textAlign: "center",
          gap: "0.95rem",
          padding: "clamp(1.7rem, 4.5vw, 3rem) 0",
        }}
      >
        <h3 style={{ margin: 0, color: "#eef3ff", fontSize: "clamp(1.2rem, 2.8vw, 1.7rem)" }}>내 사이즈 분석 시작하기</h3>
        <motion.div
          whileHover={{ y: -2, scale: 1.01 }}
          transition={{ type: "spring", stiffness: 220, damping: 20 }}
          style={{ width: "100%", maxWidth: 320 }}
        >
          <LandingStartSection />
        </motion.div>
      </motion.section>

      <section
        style={{
          display: "flex",
          justifyContent: "space-between",
          gap: "0.8rem",
          flexWrap: "wrap",
          color: "#cbcbcb",
          fontSize: "0.9rem",
        }}
      >
        <span>추천은 입력한 실측과 mock 상품 사이즈표를 기준으로 한 참고 결과입니다.</span>
        <span>
          <Link href="/privacy">개인정보</Link> · <Link href="/terms">이용약관</Link>
        </span>
      </section>
    </section>
  );
}

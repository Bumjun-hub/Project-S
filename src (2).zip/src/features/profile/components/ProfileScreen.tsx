// 이 파일은 사용자 프로필 입력 화면과 저장 동작을 정의합니다.
"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Button } from "@/components/common/Button";
import { FlowStepCaption } from "@/components/common/FlowStepCaption";
import { Input } from "@/components/common/Input";
import { Select } from "@/components/common/Select";
import { PageContainer } from "@/components/layout/PageContainer";
import type { UserProfileState } from "@/features/profile/types";
import { useUserProfileStore } from "@/features/profile/store";

export default function ProfileScreen() {
  const router = useRouter();
  const profile = useUserProfileStore((s) => s.profile);
  const setProfile = useUserProfileStore((s) => s.setProfile);

  const [height, setHeight] = useState(profile.heightCm?.toString() ?? "");
  const [weight, setWeight] = useState(profile.weightKg?.toString() ?? "");
  const [gender, setGender] = useState<UserProfileState["gender"]>(profile.gender);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const h = height.trim() === "" ? null : Number(height);
    const w = weight.trim() === "" ? null : Number(weight);
    if (h == null || Number.isNaN(h) || w == null || Number.isNaN(w)) {
      alert("키와 몸무게를 숫자로 입력해 주세요.");
      return;
    }
    setProfile({ heightCm: h, weightKg: w, gender: gender || "" });
    router.push("/my-fit");
  }

  return (
    <PageContainer maxWidth={480}>
      <FlowStepCaption step={2} label="사용자 프로필" />
      <h1 style={{ marginTop: 0 }}>체형 프로필</h1>
      <p style={{ color: "var(--muted)" }}>추천 mock AI가 참고할 최소 정보입니다.</p>
      <form onSubmit={submit} style={{ display: "grid", gap: "1rem" }}>
        <label style={{ display: "grid", gap: 4 }}>
          <span>키 (cm)</span>
          <Input
            name="height"
            inputMode="decimal"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            required
          />
        </label>
        <label style={{ display: "grid", gap: 4 }}>
          <span>몸무게 (kg)</span>
          <Input
            name="weight"
            inputMode="decimal"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            required
          />
        </label>
        <label style={{ display: "grid", gap: 4 }}>
          <span>성별 (선택)</span>
          <Select value={gender} onChange={(e) => setGender(e.target.value as typeof gender)}>
            <option value="">선택 안 함</option>
            <option value="male">남성</option>
            <option value="female">여성</option>
            <option value="other">기타</option>
          </Select>
        </label>
        <Button type="submit">저장 후 다음</Button>
      </form>
      <p style={{ marginTop: "1.5rem" }}>
        <Link href="/">← 랜딩</Link>
      </p>
    </PageContainer>
  );
}

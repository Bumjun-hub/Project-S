// 이 파일은 앱 전반에서 사용하는 기본 셀렉트 컴포넌트를 정의합니다.
import type { SelectHTMLAttributes } from "react";

export type SelectProps = SelectHTMLAttributes<HTMLSelectElement>;

export function Select({ style, ...rest }: SelectProps) {
  return <select {...rest} style={{ padding: "0.5rem 0.75rem", width: "100%", ...style }} />;
}

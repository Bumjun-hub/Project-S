// 이 파일은 앱 전반에서 사용하는 기본 입력 컴포넌트를 정의합니다.
import type { InputHTMLAttributes } from "react";

export type InputProps = InputHTMLAttributes<HTMLInputElement>;

export function Input({ style, ...rest }: InputProps) {
  return <input {...rest} style={{ padding: "0.5rem 0.75rem", width: "100%", ...style }} />;
}
